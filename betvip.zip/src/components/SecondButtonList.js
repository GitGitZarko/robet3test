import React, { Component } from 'react';
import { Header, Table, Button, SegmentInline, Ref} from 'semantic-ui-react'

class SecondButtonList extends Component {
    constructor(props) {
        super(props);
    
        this.buttonRef = React.createRef();
      }
 
    componentDidMount(){
        console.log(this.buttonRef.current.innerText)
     }

        render() {       
          
         return (                            
                   <button className="ui orange button" ref={this.buttonRef} toggle onClick={() => console.log(this.buttonRef.current.innerText)}>{this.props.buttonName}</button>                     
             )
       }
    
    }    
    export default SecondButtonList;