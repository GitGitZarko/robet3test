import React, { Component } from 'react';
import { Header, Table, Button, SegmentInline, Ref} from 'semantic-ui-react'

class MainButtonList extends Component {
    constructor(props) {
        super(props);
    
        this.buttonRef = React.createRef();
      }
 

        render() {       
        
         return (                            
                   <button className="ui orange button" ref={this.buttonRef} onClick={() => console.log(this.buttonRef.current, this.props.sportId + "koje picke materine" + this.props.tourId)}>{this.props.buttonName}</button>                     
             )
       }
    
    }    
    export default MainButtonList;